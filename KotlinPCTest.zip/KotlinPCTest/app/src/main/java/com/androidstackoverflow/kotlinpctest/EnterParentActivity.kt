package com.androidstackoverflow.kotlinpctest

import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.support.design.widget.Snackbar
import android.support.v7.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_enter_parent.*

class EnterParentActivity : AppCompatActivity() {

    var idD = 0
    var fkD = 0
    var from = ""
    private var ET = ""
    val dbManager = DBHelper(this)
    // dbManager is now GLOBAL in EnterParentActivity
    // ==============================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_parent)
        title = "Enter Departments"

        try {
            val bundle: Bundle = intent.extras
            idD = bundle.getInt("MainActId", 0)
            fkD = bundle.getInt("PFK",0)
            from = bundle.getString("FROM","")
            ET = bundle.getString("ET","")
            if(from == "U"){
                btnSaveDeptData.visibility = View.INVISIBLE
                btnViewDeptList.visibility = View.INVISIBLE
                btnDeleteDept.visibility = View.VISIBLE
                btnEditDept.visibility = View.VISIBLE
                etDeptData.setText(ET)
                etDeptFK.isFocusable = false // Prevents changing fkD value on EDIT
                if(fkD != 0){
                    etDeptFK.setText(fkD.toString())
                }
            }else{
                btnSaveDeptData.visibility = View.VISIBLE
                btnViewDeptList.visibility = View.VISIBLE
                btnDeleteDept.visibility = View.INVISIBLE
                btnEditDept.visibility = View.INVISIBLE
                etDeptData.setText(ET)
                if(fkD != 0){
                    etDeptFK.setText(fkD.toString())
                }
            }
            if (idD != 0) {

                //etPerson.setText(bundle.getString("ET"))
                //etPerson.setText("We Have no Records")
            }
        } catch (ex: Exception) {
        }

        btnEditDept.setOnClickListener {

            if (etDeptData.text.toString().equals("")) {
                message("ENTER Dept")
                etDeptData.requestFocus()
                return@setOnClickListener
            }

            if (etDeptFK.text.toString().equals("") || etDeptFK.text.toString().toInt() == 0) {
                message("ENTER foreign key")
                etDeptFK.requestFocus()
                return@setOnClickListener
            }

            val values = ContentValues()
            values.put("dept", etDeptData.text.toString())
            values.put("fkD",Integer.parseInt(etDeptFK.text.toString()))

            if (idD > 0) {
                // IN UPDATE idD needs to be idD > 0
                val selectionArs = arrayOf(idD.toString())
                val mID = dbManager.updateDEPT(values, "idD=?", selectionArs)

                if (mID > 0) {
                    tvMsg.setTextColor(Color.RED)
                    message("Updated Dept successfully")
                    //Timer().schedule(800){
                    nextACTIVITY()
                    //}
                } else {
                    message("Failed to Update Dept")
                }
            }
        }

        btnSaveDeptData.setOnClickListener{
            if (etDeptData.text.toString().equals("")) {
                message("ENTER Dept")
                etDeptData.requestFocus()
                return@setOnClickListener
            }

            if (etDeptFK.text.toString().equals("") || etDeptFK.text.toString().toInt() == 0) {
                message("ENTER foreign key")
                etDeptFK.requestFocus()
                return@setOnClickListener
            }

            // THIS ERROR TRAP MUST BE below THE OTHER
            // ERROR TRAPS to prevent DUPLICATE fkD VALUES
            // ============================================
            val EnterValue = etDeptFK.text.toString().trim()// START as String
            val result = dbManager.getItem(EnterValue.toInt())// CHANGE to Int for SEARCH
            val RetriveDEPT = result?.dept.toString().trim()
            val RetriveValue = result?.fkD.toString().trim()// RetriveValue is a Int

            if(EnterValue == RetriveValue){

                etDeptData.setText("$RetriveDEPT is Using the ID $RetriveValue")

                catchDUPfk(it)

                return@setOnClickListener
            }

            val values = ContentValues()
            values.put("dept", etDeptData.text.toString())
            values.put("fkD",Integer.parseInt(etDeptFK.text.toString()))
            // the put MUST MATCH the Model <--- READ
            if (idD == 0) {
                // In INSERT or SAVE idD = 0 see updateDeptData
                val mID = dbManager.insertDEPT(values)

                if (mID > 0) {
                    tvMsg.setTextColor(Color.RED)
                    message("ADDED Dept successfully")
                    //Timer().schedule(800){
                    nextACTIVITY()
                    //}
                } else {
                    message("Failed to Add Dept")
                }
            }
        }

        btnDeleteDept.setOnClickListener {
            if (etDeptData.text.toString().equals("")) {
                message("No Match Found")
                return@setOnClickListener
            }
            doCustom()
        }

    }// end onCreate

    fun catchDUPfk(view: View){

        val ActionType = "CLEAR"
        val ID = etDeptFK.text.toString().trim()

        val snackbar = Snackbar.make(view, "ID $ID is Being Used", Snackbar.LENGTH_INDEFINITE)
            .setAction(ActionType) {etDeptFK.setText("");etDeptData.setText("");etDeptData.requestFocus() }

        snackbar.setActionTextColor(Color.RED)
        val snackbarView = snackbar.view
        snackbarView.setBackgroundColor(Color.LTGRAY)
        val textView = snackbarView.findViewById(android.support.design.R.id.snackbar_text) as TextView
        val actionTextView = snackbarView.findViewById(android.support.design.R.id.snackbar_action)as TextView
        textView.setTextColor(Color.BLUE)
        textView.textSize = 22f
        actionTextView.textSize = 20f
        snackbar.show()
    }

    fun nextACTIVITY(){
        val intent = Intent(this, ViewParentActivity::class.java)
        startActivity(intent)
    }

    fun thisACTIVITY(){
        val intent = Intent(this, EnterParentActivity::class.java)
        intent.putExtra("FROM", "N")
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(intent)
    }

    fun onViewDeptList(view: View){
        nextACTIVITY()
    }

    fun doCustom() {
        /* This method uses the custom_dialog.xml file created for greater control over
       the styling of the Custom Alert Dialog for various screen sizes and to be
       able to set the text size of the dialog message text
       */
        val makeDialog = LayoutInflater.from(this).inflate(R.layout.custom_dialog,null)
        val mBuilder = AlertDialog.Builder(this).setView(makeDialog)
        val mAlertDialog = mBuilder.show()

        val btnYES = makeDialog.findViewById<Button>(R.id.btnYES)
        val btnNO = makeDialog.findViewById<Button>(R.id.btnNO)
        mAlertDialog.setCancelable(false)

        btnYES.setOnClickListener {
            removeDEPT()
            mAlertDialog.dismiss()
        }

        btnNO.setOnClickListener {
            message("Record NOT Deleted")
            etDeptData.setText("")
            //Timer().schedule(800){
            thisACTIVITY()
            //}
            mAlertDialog.dismiss()
        }
        mAlertDialog.show()
    }

    private fun removeDEPT() {

        val result = dbManager.deleteDEPT(etDeptData.text.toString())

        if (result) {
            etDeptData.setText("")
            message("Record Removed")
            //Timer().schedule(1000){
            thisACTIVITY()
            //}
        }else{
            etDeptData.setText("NO MATCH -> click View Dept List")
            btnViewDeptList.visibility = View.VISIBLE
            btnEditDept.visibility = View.INVISIBLE
            btnDeleteDept.visibility = View.INVISIBLE
            btnSaveDeptData.visibility = View.INVISIBLE
            message("NO Match Found")
        }
    }

    fun message(msg:String){
        object : CountDownTimer(4000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tvMsg.visibility = View.VISIBLE
                tvMsg.text = msg
            }
            override fun onFinish() {
                tvMsg.visibility = View.INVISIBLE
                tvMsg.text = ""
            }
        }.start()
    }

    fun onBACK(view: View){
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }

    override fun onBackPressed(){
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }

}// end Class
