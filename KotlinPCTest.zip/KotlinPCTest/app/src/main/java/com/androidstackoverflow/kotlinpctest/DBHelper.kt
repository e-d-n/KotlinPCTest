package com.androidstackoverflow.kotlinpctest

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

class DBHelper(private val context: Context): SQLiteOpenHelper(context,DBHelper.DB_NAME,null,DBHelper.DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase?) {

        val CREATE_TABLE_DEPT = "CREATE TABLE $PARENT_TABLE ($colidD INTEGER PRIMARY KEY,$colDept TEXT,$colPFK INTEGER);"
        val CREATE_TABLE_ITEM = "CREATE TABLE $CHILD_TABLE ($colidI INTEGER PRIMARY KEY,$colItem TEXT,$colCFK INTEGER);"
        db!!.execSQL(CREATE_TABLE_DEPT)
        db.execSQL(CREATE_TABLE_ITEM)

        Toast.makeText(context,"database was created", Toast.LENGTH_LONG).show()
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val DROP_TABLE_DEPT = "DROP TABLE IF EXISTS $PARENT_TABLE"
        val DROP_TABLE_ITEM = "DROP TABLE IF EXISTS $CHILD_TABLE"
        db!!.execSQL(DROP_TABLE_DEPT)
        db.execSQL(DROP_TABLE_ITEM)
        onCreate(db)

        Toast.makeText(context,"tables dropped new DB", Toast.LENGTH_LONG).show()
    }

    fun getItem(fkD: Int): Parent? {
        val db = this.writableDatabase
        val selectQuery = "SELECT  * FROM $PARENT_TABLE WHERE $colPFK = ?"
        db.rawQuery(selectQuery, arrayOf(fkD.toString())).use { // .use requires API 16
            if (it.moveToFirst()) {
                val result = Parent()
                result.fkD = it.getInt(it.getColumnIndex(colPFK))
                result.dept = it.getString(it.getColumnIndex(colDept))
                return result
            }
        }
        db.close()
        return null
    }

    fun queryDEPT(): ArrayList<Parent> {
        val db = this.writableDatabase
        val parentList = ArrayList<Parent>()
        val selectQuery = "SELECT  * FROM $PARENT_TABLE"
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    val contact = Parent()
                    contact.idD = Integer.parseInt(cursor.getString(cursor.getColumnIndex(colidD)))
                    contact.dept = cursor.getString(cursor.getColumnIndex(colDept))
                    contact.fkD = Integer.parseInt(cursor.getString(cursor.getColumnIndex(colPFK)))
                    parentList.add(contact)
                } while (cursor.moveToNext())
            }
        }
        cursor.close()
        db.close()
        return parentList
    }

    fun queryCHILD(fkI: Int): ArrayList<Child> {
        val db = this.writableDatabase
        val childList = ArrayList<Child>()
        val selectQuery = "SELECT  * FROM $CHILD_TABLE WHERE $colCFK = ?"
        val cursor = db.rawQuery(selectQuery, arrayOf(fkI.toString()))
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    val contact = Child()
                    contact.idI = Integer.parseInt(cursor.getString(cursor.getColumnIndex(colidI)))
                    contact.item = cursor.getString(cursor.getColumnIndex(colItem))
                    contact.fkI = Integer.parseInt(cursor.getString(cursor.getColumnIndex(colCFK)))
                    childList.add(contact)
                } while (cursor.moveToNext())
            }
        }
        cursor.close()
        db.close()
        return childList
    }

    fun queryITEM(): ArrayList<Child> {
        val db = this.writableDatabase
        val childList = ArrayList<Child>()
        val selectQuery = "SELECT  * FROM $CHILD_TABLE"
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    val contact = Child()
                    contact.idI = Integer.parseInt(cursor.getString(cursor.getColumnIndex(colidI)))
                    contact.item = cursor.getString(cursor.getColumnIndex(colItem))
                    contact.fkI = Integer.parseInt(cursor.getString(cursor.getColumnIndex(colCFK)))
                    childList.add(contact)
                } while (cursor.moveToNext())
            }
        }
        cursor.close()
        db.close()
        return childList
    }

    fun insertDEPT(values: ContentValues): Long {
        val db = this.writableDatabase
        val idD = db.insert(PARENT_TABLE, null, values)
        db.close()
        return idD
    }

    fun updateDEPT(values: ContentValues, selection: String, selectionargs: Array<String>):Int{
        val db = this.writableDatabase
        val dept = db.update(PARENT_TABLE,values,selection,selectionargs)
        db.close()
        return dept
    }

    fun insertITEM(values: ContentValues): Long {
        val db = this.writableDatabase
        val idI = db.insert(CHILD_TABLE, null, values)
        db.close()
        return idI
    }

    fun updateITEM(values: ContentValues, selection: String, selectionargs: Array<String>): Int {
        val db = this.writableDatabase
        val count = db.update(CHILD_TABLE, values, selection, selectionargs)
        db.close()
        return count
    }

    fun deleteDEPT(productname: String): Boolean {
        var result = false
        val query = "SELECT * FROM $PARENT_TABLE WHERE $colDept= \"$productname\""
        val db = this.writableDatabase
        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            val id = Integer.parseInt(cursor.getString(0))
            db.delete(PARENT_TABLE, "$colidD = ?", arrayOf(id.toString()))
            cursor.close()
            result = true
        }
        db.close()
        return result
    }

    fun deleteITEM(productname: String): Boolean {
        var result = false
        val query = "SELECT * FROM $CHILD_TABLE WHERE $colItem= \"$productname\""
        val db = this.writableDatabase
        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            val id = Integer.parseInt(cursor.getString(0))
            db.delete(CHILD_TABLE, "$colidI = ?", arrayOf(id.toString()))
            cursor.close()
            result = true
        }
        db.close()
        return result
    }

    companion object {
        private val DB_VERSION = 1
        private val DB_NAME = "ShoppingList.db"
        private val PARENT_TABLE = "Parent"
        private val colidD = "idD"
        private val colDept = "Dept"
        private val colPFK = "fkD"
        private val CHILD_TABLE = "Child"
        private val colidI = "idI"
        private val colItem = "Item"
        private val colCFK = "fkI"
    }
}