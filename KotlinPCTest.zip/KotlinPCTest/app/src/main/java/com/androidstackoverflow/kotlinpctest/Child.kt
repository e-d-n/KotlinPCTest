package com.androidstackoverflow.kotlinpctest

data class Child(var idI:Int = 0) {
    var item:String = ""
    var fkI:Int = 0
}