package com.androidstackoverflow.kotlinpctest

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.MenuItem
import android.view.View
import kotlinx.android.synthetic.main.activity_sdview.*


class SDViewActivity : AppCompatActivity() {

    private var RecyclerAdapter: SDViewAdapter? = null
    private var recyclerView: RecyclerView? = null
    private val db = DBHelper(this)
    private var parentList:List<Parent> = ArrayList()
    private var linearLayoutManager: LinearLayoutManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sdview)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        initViews()
    }

    override fun onResume() {
        super.onResume()
        initDB()
    }

    // This is ONLY called when Activity is in onResume state
    private fun initDB() {
        parentList = db.queryDEPT()
        if(parentList.isEmpty()){
            title = "No Records in DB"
            message("Enter Dept Data First")
        }else{
            title = "Select the Department"
            message("Select the Department to Enter\nthe Corrisponding Grocery Item")
        }

        RecyclerAdapter = SDViewAdapter(parentList = parentList, context = applicationContext)
        (recyclerView as RecyclerView).adapter = RecyclerAdapter
    }

    private fun initViews() {
        recyclerView = this.findViewById(R.id.rvParentView)
        RecyclerAdapter = SDViewAdapter(parentList = parentList, context = applicationContext)
        linearLayoutManager = LinearLayoutManager(applicationContext)
        (recyclerView as RecyclerView).layoutManager = linearLayoutManager!!
    }

    fun message(msg:String){
        object : CountDownTimer(6000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tvMULTLINE.visibility = View.VISIBLE
                tvMULTLINE.setText(msg)
            }
            override fun onFinish() {
                tvMULTLINE.visibility = View.INVISIBLE
                tvMULTLINE.setText("")
            }
        }.start()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {

            val id = item.itemId
            if (id == android.R.id.home) {
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("FROM","N")// ADD NEW NOTE
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
