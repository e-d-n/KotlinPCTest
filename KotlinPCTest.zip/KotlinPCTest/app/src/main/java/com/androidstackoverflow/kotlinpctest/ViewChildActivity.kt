package com.androidstackoverflow.kotlinpctest

import android.content.Intent
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast

class ViewChildActivity : AppCompatActivity() {

    private var RecyclerAdapter: ChildAdapter? = null
    private var recyclerView: RecyclerView? = null
    private val db = DBHelper(this)
    private var childList:ArrayList<Child> = ArrayList()
    private var linearLayoutManager: LinearLayoutManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_child)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        initViews()
    }// end onCreate

    override fun onResume() {
        super.onResume()
        initDB()
    }

    // This is ONLY called when Activity is in onResume state
    private fun initDB() {

        childList = db.queryITEM()

        if(childList.isEmpty()){
            title = "No Records in DB"
        }else{
            title = "Grocery Items"
        }

        RecyclerAdapter = ChildAdapter(childList = childList, context = applicationContext)
        (recyclerView as RecyclerView).adapter = RecyclerAdapter
    }

    private fun initViews() {

        recyclerView = this.findViewById(R.id.rvChildView)
        RecyclerAdapter = ChildAdapter(childList = childList, context = applicationContext)
        linearLayoutManager = LinearLayoutManager(applicationContext)
        (recyclerView as RecyclerView).layoutManager = linearLayoutManager!!
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            // CODE below manages HOME Button
            val id = item.itemId
            if (id == android.R.id.home) {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed(){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        theTOAST()
    }

    fun theTOAST(){
        val toast = Toast.makeText(this, "Add New Grocery Item Here", Toast.LENGTH_LONG)
        val view = toast.view
        view.setBackgroundColor(Color.TRANSPARENT)
        val text = view.findViewById(android.R.id.message) as TextView
        text.setTextColor(Color.BLUE)
        text.textSize = (20F)
        toast.show()
    }

}// end Class
