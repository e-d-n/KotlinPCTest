package com.androidstackoverflow.kotlinpctest

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_view_pc.*
import java.util.ArrayList

class ViewPCActivity : AppCompatActivity() {

    private val db = DBHelper(this)
    private var parentList:List<Parent> = ArrayList()
    private var childList:List<Child> = ArrayList()
    var sizePL = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_pc)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Shopping List"

        val db = DBHelper(this)
        parentList = db.queryDEPT()
        parentList = db.queryDEPT()
        if(parentList.isEmpty()){
            title = "No Records in DB"
        }else{
            title = "Shopping List"
        }

        sizePL = parentList.size

        val parents = buildData()
        list.adapter = ParentChildAdapter(this, parents)
    }

    private fun buildData(): List<Parent> {

        val reply = parentList
        for (idx in 0 until sizePL) {
            apply { parentList }

            val PARENT_LIST_FK = parentList.get(idx).fkD
            childList = db.queryCHILD(PARENT_LIST_FK)
            val CL = childList.size

            for (idx2 in 0..CL - 1) {
                val CHILD_ITEM = childList[idx2].item
                reply[idx].addChild(idx2,CHILD_ITEM)
            }
        }
        return reply
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            // CODE below manages HOME Button
            val id = item.itemId
            if (id == android.R.id.home) {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
